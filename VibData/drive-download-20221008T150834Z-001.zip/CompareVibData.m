load('AllResults.mat');
% load('MicrophoneOutput.mat');
load('VibrometerOutput.mat');

figure;

for j = 1:length(device_names)
   subplot(2, 4, j);
   title(device_names{j});
   yyaxis left;
   loglog(out_x(j,:), out_values(j, :));
   yyaxis right;
   loglog(freqs, mag_out(j,:));
   j = j + 1; 
end